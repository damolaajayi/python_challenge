Clone this repository

Run `pip install python-challenge` to install module

Run `python setup.py test` to run test